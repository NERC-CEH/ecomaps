#coverage_setup = list("http://tds1-dev.nerc-lancaster.ac.uk/thredds/fileServer/CHESSDetail/ChessAnnualTotalPrecip.nc" = list("precip"))

coverage_setup = list("http://localhost:8080/thredds/fileServer/testAll/CHESSAnnualTotalPrecip.nc" = list("precip"))

time_slices = list("precip"=1)

progress_rep_file = "progress.txt"
user_name = "Test Harness"
email_address = "test@test.com"
csv_file = "InputRDataFile.csv"
map_image_file = "map_output.png"
fit_image_file = "fit_output.png"
temp_netcdf_file = "temp.nc"
output_netcdf_file = "output.nc"

source("LCM_thredds_model.r", chdir=TRUE)


